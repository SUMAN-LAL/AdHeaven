<div class="copyrights">
	 <p>© 2020 Adheaven All Rights Reserved |  <a href="#">Adheaven</a> </p>
</div>	
